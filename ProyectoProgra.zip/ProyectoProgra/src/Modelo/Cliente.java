/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class Cliente {
    private String nombre;
    private int CI;
    private int telefono;
    //java.util.List<String> lista= new ArrayList<>();
    private static final String FILE_NAME = "clientes.txt";
    
    
    public Cliente(String nombre, int CI, int telefono) {
        //his.lista = new ArrayList<>();
        //this.lista = new ArrayList<>();
        this.nombre = nombre;
        this.CI = CI;
        this.telefono = telefono;
    }
    
    public Cliente() {
      //this.lista = new ArrayList<>();
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCI() {
        return CI;
    }

    public void setCI(int CI) {
        this.CI = CI;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    public static String[] Comprimir(String nombre, int CI , int telefono){
        String[] lista1 = {nombre , Integer.toString(CI), Integer.toString(telefono)};
        return lista1;
    }
    
    
    /*private void readNames(java.util.List<String> lista){
        try(BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))){
            String line;
            while((line = reader.readLine())!=null){
                lista.add(line);
            }
        }catch(Exception e){
            System.out.println("Error al leer archivo " + e.getMessage());
        }
    }
    
    private void writeNames(java.util.List<String> lista1){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))){
            for (String lista11 : lista) {
                writer.write(lista11);
                
                writer.newLine();
            }
        }catch(IOException e){
                System.out.print("ERROR AL ESCRIBIR EL ARCHIVO " + e.getMessage());
            }
    }*/
    public void Guardar(){
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))){
            writer.write(nombre);
            writer.write(nombre);
            writer.write(nombre);
            writer.newLine();
        }catch(IOException e){
            System.out.println("Error al escribir");
        }
    }

    public void readNames() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}


