/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class ClienteDAO extends Cliente {
    String[] lista = new String[3];
    
    
    public boolean RegistrarCliente(Cliente cl){
        try {
            lista[0] = getNombre();
            lista[1] = Integer.toString(getCI());
            lista[2] = Integer.toString(getTelefono());
            return true;
        } catch(Exception e ){
            JOptionPane.showMessageDialog(null, e.toString());
            return false;
        }
    }
}
